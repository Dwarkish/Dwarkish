<?php

	$db = mysqli_connect("localhost","root","","myshop");
	session_start();
	
	function getRealIpAddr()
	{
		if(!empty($_SERVER['HTTP_CLIENT_IP']))
		{
			$ip=$_SERVER['HTTP_CLIENT_IP'];
		}
		elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
		{
			$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else
		{
			$ip=$_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
	
	
	function cart(){
		if(isset($_GET['pro_id'])){
			
			global $db;
			
			$p_id = $_GET['pro_id'];
			
			$ip_add = getRealIpAddr();
			
			$check_pro = "select * from cart where ip_add='$ip_add' AND p_id='$p_id'";
			
			$run_check = mysqli_query($db, $check_pro);
			
			if(mysqli_num_rows($run_check)>0){
				
				echo "";
			}
			else{
				$q = "insert into cart (p_id,ip_add) values ('$p_id','$ip_add')";
				$run_q = mysqli_query($db,$q);
				
				echo "";
			}
		}
	}
	
	
	function getPro1(){
		
		global $db;
		
		$get_products = "select * from products where cat_id=14 order by rand() LIMIT 0,2";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:20px;margin-left:13px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='155' height='160'/></a><br>
								</div>
							";
						
						}
	}
	
	function getPro2(){
		
		global $db;
		
		$get_products = "select * from products where cat_id=14 order by rand() LIMIT 0,2";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:13px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='155' height='160'/></a><br>
								</div>
							";
						
						}
	}
	
	function getPro3(){
		
		global $db;
		
		$get_products = "select * from products where cat_id=15 order by rand() LIMIT 0,2";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:13px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='155' height='160'/></a><br>
								</div>
							";
						
						}
	}
	
	function getPro4(){
		
		global $db;
		
		$get_products = "select * from products where cat_id=15 order by rand() LIMIT 0,2";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:13px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='155' height='160'/></a><br>
								</div>
							";
						
						}
	}
	
	function getPro5(){
		
		global $db;
		
		$get_products = "select * from products where cat_id=29 order by rand() LIMIT 0,2";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:13px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='155' height='160'/></a><br>
								</div>
							";
						
						}
	}
	
	function getPro6(){
		
		global $db;
		
		$get_products = "select * from products where cat_id=29 order by rand() LIMIT 0,2";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:13px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='155' height='160'/></a><br>
								</div>
							";
						
						}
	}
	
	function getPro7(){
		
		global $db;
		
		$get_products = "select * from products where cat_id=16 order by rand() LIMIT 0,2";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:13px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='155' height='160'/></a><br>
								</div>
							";
						
						}
	}
	
	function getPro8(){
		
		global $db;
		
		$get_products = "select * from products where cat_id=17 order by rand() LIMIT 0,2";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:13px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='155' height='160'/></a><br>
								</div>
							";
						
						}
	}
	
	function getPro9(){
		
		global $db;
		
		$get_products = "select * from products order by rand() LIMIT 0,6";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:13px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='230' height='280'/></a><br>
								</div>
							";
						
						}
	}
	
	
	function getCats(){
		
		global $db;
		
		$get_cats = "select * from categories";
					$run_cats = mysqli_query($db, $get_cats);
					
					while($row_cats=mysqli_fetch_array($run_cats)){
						
						$cat_id = $row_cats['cat_id'];
						$cat_title = $row_cats['cat_title'];
						
						echo "<li><a href='categories.php?cat=$cat_id'>$cat_title</a></li>";
					}
	}
	
	function getBuyPro(){
			global $db;
		
		if(isset($_GET['pro_id'])){
			
			$p_id = $_GET['pro_id'];
			$get_cart_pro = "select * from products where product_id='$p_id'";
			$run_cart_pro = mysqli_query($db, $get_cart_pro);
			
			while($row_cart_pro=mysqli_fetch_array($run_cart_pro)){
				$pro_id = $row_cart_pro['product_id'];
				$pro_title = $row_cart_pro['product_title'];
				$pro_desc = $row_cart_pro['product_desc'];
				$pro_price = $row_cart_pro['product_price'];
				$pro_image = $row_cart_pro['product_img1'];	
				
				echo "	
					<div style ='margin-top:20px;margin-left:15px;margin-bottom:10px;border-bottom:2px solid #EBECF0;display:flex;'>
					<a href='details.php?pro_id=$pro_id'><img src='admin_area/product_images/$pro_image' width='250' height='200'/></a><br>
					<div style='margin-top:50px;margin-left:25px;'>
					<a style='text-decoration:none;color:black;' href='details.php?pro_id=$pro_id'><b> $pro_title </b><br></a>
					<b style='color:#b30000;'> $pro_price </b>
					</div>
					</div>
					";
			}
		}
	}
	
	
	function getCatPro(){
		global $db;
		
		if(isset($_GET['cat'])){
			
			$cat_id = $_GET['cat'];
			$get_cat_pro = "select * from products where cat_id='$cat_id'";
			$run_cat_pro = mysqli_query($db, $get_cat_pro);
			
			while($row_cat_pro=mysqli_fetch_array($run_cat_pro)){
				$pro_id = $row_cat_pro['product_id'];
				$cat_id = $row_cat_pro['cat_id'];
				$brand_id = $row_cat_pro['brand_id'];
				$pro_title = $row_cat_pro['product_title'];
				$pro_desc = $row_cat_pro['product_desc'];
				$pro_price = $row_cat_pro['product_price'];
				$pro_image = $row_cat_pro['product_img1'];	
				
				echo "	
					<div style ='margin-top:20px;margin-left:15px;margin-bottom:10px;border-bottom:2px solid #EBECF0;display:flex;'>
					<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='250' height='200'/></a><br>
					<div style='margin-top:50px;margin-left:25px;'>
					<a style='text-decoration:none;color:black;' href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><b> $pro_title </b><br></a>
					<b style='color:#b30000;'> $pro_price </b>
					</div>
					</div>
					";
			}
		}
	}
	
	function getBrandsPro(){
		global $db;
		
		if(isset($_GET['brand'])){
			
			$brand_id = $_GET['brand'];
			$get_brand_pro = "select * from products where brand_id='$brand_id'";
			$run_brand_pro = mysqli_query($db, $get_brand_pro);
			
			while($row_brand_pro=mysqli_fetch_array($run_brand_pro)){
				$pro_id = $row_brand_pro['product_id'];
				$cat_id = $row_brand_pro['cat_id'];
				$brand_id = $row_brand_pro['brand_id'];
				$pro_title = $row_brand_pro['product_title'];
				$pro_desc = $row_brand_pro['product_desc'];
				$pro_price = $row_brand_pro['product_price'];
				$pro_image = $row_brand_pro['product_img1'];	
				
				echo "	
					<div style ='margin-top:20px;margin-left:15px;margin-bottom:10px;border-bottom:2px solid #EBECF0;display:flex;'>
					<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='250' height='200'/></a><br>
					<div style='margin-top:50px;margin-left:25px;'>
					<a style='text-decoration:none;color:black;' href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><b> $pro_title </b><br></a>
					<b style='color:#b30000;'> $pro_price </b>
					</div>
					</div>
					";
			}
		}
	}
	
	function getBrands(){
		
		global $db;
		
		$get_brands = "select * from brands";
					$run_brands = mysqli_query($db, $get_brands);
					
					while($row_brands=mysqli_fetch_array($run_brands)){
						
						$brand_id = $row_brands['brand_id'];
						$brand_title = $row_brands['brand_title'];
						
						echo "<li><a href='brands.php?brand=$brand_id'>$brand_title</a></li>";
					}
	}

?>




