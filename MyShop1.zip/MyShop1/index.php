<?php
include("includes/db.php");
include("functions/functions.php");
?>

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" name="viewport" content="width=device-width,initial-scale=1.0" />
<title>My Shop</title>

<link rel="stylesheet" href="styles/style.css" media="all" />
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css" media="all" />
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body bgcolor="#FAFAFA">
	
<div class="main_wrapper">
	
	
	<div class="header_wrapper">
		<a href="index.php"><img src="images/logo.png"></a>
	    
		<ul class="menu">
			<li><a href="index.php">HOME</a></li>
			<li>|</li>
			<li><a href="about_us.php">ABOUT US</a></li>
			<li>|</li>
			<li><a href="categories.php">CATEGORIES</a></li>
			<li>|</li>
			<li><a href="our_services.php">OUR SERVICES</a></li>
			<li>|</li>
			<li><a href="contact_us.php">CONTACT US</a></li>
		</ul>
		
		<form method="get" action="results.php" enctype="multipart/form-data" style="margin-top:5px;margin-left:20px;">
			<input type="text" name="user_query" placeholder="Search" style="padding:7px"/>
			<input type="submit" name="search" value="Search" style="padding:7px;float:right;"/>
		</form>
		
		<ul class="menu">
			<li><a href="cart.php">CART</a></li>
			<li>
			<?php
						
						if(!isset($_SESSION['customer_email'])){
					
						echo "&nbsp;<a href='login.php'>LOGIN</a>";
						}
						else{
							
							echo "<a href='logout.php'>LOGOUT</a>";
						}
						
			?>
			</li>
		</ul>
	</div>
	
	<div class="main">
		
		<img class="slide" src="images/bg12.jpg">
		<img class="slide" src="images/dg1.jpg">
		<img class="slide" src="images/dg0.jpg">
		<img class="slide" src="images/bg3.jpg">
		<img class="slide" src="images/dg14.jpg">
		
		<a class="w3-display-left" style="cursor:pointer;" onclick="plusDivs(-1)">&#10094;</a>
		<a class="w3-display-right" style="cursor:pointer;" onclick="plusDivs(+1)">&#10095;</a>
		
	</div>
	
	<script src="myScript.js"></script>
	
	<div style="width:1519px;display:flex;height:430px;margin-top:30px;margin-left:auto;margin-right:auto;margin-bottom:10px;">
		<div style="width:350px;height:430px;margin-left:24px;background:#FAFAFA;"> 
		<h2 style="margin-left:5px;margin-top:5px;">Televison</h2>
		<div style="display:flex;">
		<?php getPro1(); ?>
		</div>
		
		<div style="display:flex;">
		<?php getPro2(); ?>
		</div>
		</div>
		
		<div style="width:350px;height:430px;margin-left:24px;background:#FAFAFA;"> 
		<h2 style="margin-left:5px;margin-top:5px;">Headphones</h2>
		<div style="display:flex;">
		<?php getPro3(); ?>
		</div>
		
		<div style="display:flex;">
		<?php getPro4(); ?>
		</div>
		</div>
		
		<div style="width:350px;height:430px;margin-left:24px;background:#FAFAFA;"> 
		<h2 style="margin-left:5px;margin-top:5px;">Mobiles</h2>
		<div style="display:flex;">
		<?php getPro5(); ?>
		</div>
		
		<div style="display:flex;">
		<?php getPro6(); ?>
		</div>
		</div>
		
		<div style="width:350px;height:430px;margin-left:24px;background:#FAFAFA;"> 
		<h2 style="margin-left:5px;margin-top:5px;">Cameras & Speakers</h2>
		<div style="display:flex;">
		<?php getPro7(); ?>
		</div>
		
		<div style="display:flex;">
		<?php getPro8(); ?>
		</div>
		</div>
	</div>
	
	<div style="width:1519px;height:300px;margin-left:auto;margin-right:auto;margin-top:50px;background:#FAFAFA;">
		<div style="width:1471px;height:300px;margin-left:24px;display:flex;"> 
		<?php getPro9(); ?>
		</div>
	</div>
	
	<div style="width:1519px;height:300px;margin-left:auto;margin-right:auto;margin-top:60px;background:#FAFAFA;">
		<div style="width:1471px;height:300px;margin-left:24px;display:flex;">
		<?php getPro9(); ?>
		</div>
	</div>
	
	<div style="width:1519px;height:300px;margin-left:auto;margin-right:auto;margin-top:60px;background:#FAFAFA;">
		<div style="width:1471px;height:300px;margin-left:24px;display:flex;"> 
		<?php getPro9(); ?>
		</div>
	</div>
	
	<div style="width:1519px;height:300px;margin-left:auto;margin-right:auto;margin-top:50px;">
		<div style="width:1000px;height:300px;margin-left:auto;margin-right:auto;"> 
		<img src="images/dg1.jpg" width="1000" height="300"/>
		</div>
	</div>
	
	<div style="width:1519px;height:300px;margin-left:auto;margin-right:auto;margin-top:50px;margin-bottom:40px;background:#FAFAFA;">
		<div style="width:1471px;height:300px;margin-left:24px;display:flex;"> 
		<?php getPro9(); ?>
		</div>
	</div>
	
	<div class="footer">
		<div class="content_left">
			<h2 class="content_heding">About us</h2>
			<div>
				<p>hytgfr vgth bcdtdgg vhyrdg vnmvhgfgd hjfhjgtuyghn vcdser cfrvd bfgtbngt vcdf ggghjn<br> nnbgf vcxsa njuk mklo nbv cvvcdd  vffvbb bvffshs bdvdferts vdfegerb sbdbvvfga cxasqwe vfgrt nmju cfgv</p>
					<div class="social">
						<a href="#"><span class="fab fa-facebook-f"></span></a>
						<a href="#"><span class="fab fa-twitter"></span></a>
						<a href="#"><span class="fab fa-instagram"></span></a>
						<a href="#"><span class="fab fa-youtube"></span></a>
					</div>
			</div>
		</div>
		
		<div class="content_center">
			<h2 class="content_heding">Address</h2>
				<div>
					<div>
						<span class="fas fa-map-market-alt"></span>
						<span class="text">Rajlot, India</span>
					</div>
					
					<div>
						<span class="fas fa-phone-alt"></span>
						<span class="text">+91-8200843427</span>
					</div>
					
					<div>
						<span class="fas fa-envelope"></span>
						<span class="text">dwarkish@gmail.com</span>
					</div>
				</div>
		</div>
		
		<div class="content_right">
				<h2 class="content_heding">Contact us</h2>
				<div>
					<ul class="footer-links">
						<li><a href="#.">Home</a></li>
						<li><a href="#.">About Us</a></li>
						<li><a href="#.">Features</a></li>
						<li><a href="#.">Categories</a></li>
						<li><a href="#.">Blog</a></li>
						<li><a href="#.">Contact Us</a></li>
					</ul>
				</div>
		</div>
		
	</div>
	
	<div class="copyright">Copyright © 2017 Classify - All Rights Reserved.</div>
</div>
</body>
</html>


