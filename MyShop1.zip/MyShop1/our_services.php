<html>
<head>
	<title>Service us</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container">
		<div class="box">
			<div class="icon">01</div>
			<div class="content">
				<h3>Free Delivery</h3>
				<p>return about our services</p>
				<a href="#">Read More</a>
			</div>
		</div>
		<div class="box">
			<div class="icon">02</div>
			<div class="content">
				<h3>Return</h3>
				<p>return about our services</p>
				<a href="#">Read More</a>
			</div>
		</div>
		<div class="box">
			<div class="icon">03</div>
			<div class="content">
				<h3>Change Product</h3>
				<p>return about our services</p>
				<a href="#">Read More</a>
			</div>
		</div>
	</div>
</body>