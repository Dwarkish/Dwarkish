
<?php

session_start();
include("includes/db.php");

?>


<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>My Shop</title>

<link rel="stylesheet" href="login.css" media="all" />

</head>

<body>
	
	<div class="login">
	<h1>Login</h1>
    <form method="post" >
    	<input  type="text" name="customer_email" placeholder="Email" required="required" /><br>
        <input  type="password" name="customer_pass" placeholder="Password" required="required" /><br>
        <button style="margin-bottom:20px;" type="submit" class="btn btn-primary btn-block btn-large" name="login">Login</button>
		<a href="forgot_pass.php"><h4 style="float:right;color:white;margin-bottom:20px;">Forgot Password?</h4><br></a>
		<a href="register.php"><h4 style="float:right;color:white;">New User? Register?</h4></a>
    </form>
</div>

</body>

</html>


<?php

	if(isset($_POST['login'])){
		
		$user_email = $_POST['customer_email'];
		$user_pass = $_POST['customer_pass'];
		
		$sel_admin = "select * from customers where customer_email='$user_email' AND customer_pass='$user_pass'";
		
		$run_admin = mysqli_query($con, $sel_admin);
		
		$check_admin = mysqli_num_rows($run_admin);
		
		if($check_admin==1){
			
			$_SESSION['customer_email']=$user_email;
			
			echo "<script>window.open('index.php?logged_in','_self')</script>";
		}
		else{
			
			echo "<script>alert('Admin Email or Password is incorrect, Try Again!')</script>";
		}
	}

?>





















