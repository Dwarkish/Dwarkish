<?php
include("includes/db.php");
include("functions/functions.php");
?>

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>My Shop</title>

<link rel="stylesheet" href="styles/style.css" media="all" />
<link rel="stylesheet" href="styles/details_style.css" media="all" />
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script src="jquery-3.3.1.min.js"></script>
<script src="bootstrap.js"></script>
</head>

<body bgcolor="#FAFAFA">
	
<div class="main_wrapper">
	
	
	<div class="header_wrapper">
		<a href="index.php"><img src="images/logo.png"></a>
	    
		<ul class="menu">
			<li><a href="index.php">HOME</a></li>
			<li>|</li>
			<li><a href="about_us.php">ABOUT US</a></li>
			<li>|</li>
			<li><a href="categories.php">CATEGORIES</a></li>
			<li>|</li>
			<li><a href="brands.php">BRANDS</a></li>
			<li>|</li>
			<li><a href="our_services.php">OUR SERVICES</a></li>
			<li>|</li>
			<li><a href="contact_us.php">CONTACT US</a></li>
		</ul>
		
		<form method="get" action="results.php" enctype="multipart/form-data" style="margin-top:5px;margin-left:20px;">
			<input type="text" name="user_query" placeholder="Search" style="padding:10px"/>
			<input type="submit" name="search" value="Search" style="padding:10px;float:right;"/>
		</form>
		
		<ul class="menu">
			<li><a href="cart.php">CART</a></li>
			<li>
			<?php
						
						if(!isset($_SESSION['customer_email'])){
					
						echo "&nbsp;<a href='login.php'>LOGIN</a>";
						}
						else{
							
							echo "<a href='logout.php'>LOGOUT</a>";
						}
						
			?>
			</li>
		</ul>
	</div>
	
	<div style="width:1519px;height:auto;margin-left:auto;margin-right:auto;display:flex;margin-top:30px;margin-bottom:30px;">
	
		<div style="width:50px;height:680px;margin-left:5px;">
		
		<?php
			
			if(isset($_GET['pro_id'])){
				
				$product_id = $_GET['pro_id'];
				$get_products = "select * from products where product_id='$product_id'";
				
				$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$pro_image1 = $row_products['product_img1'];
							$pro_image2 = $row_products['product_img2'];
							$pro_image3 = $row_products['product_img3'];
							
							echo "	
								<div>
									<img class='demo' src='admin_area/product_images/$pro_image1' onclick='currentSlide(1)' />
									<img class='demo' src='admin_area/product_images/$pro_image2' onclick='currentSlide(2)' />
									<img class='demo' src='admin_area/product_images/$pro_image3' onclick='currentSlide(3)' />
								</div>
							";
						
						}
			}
		?>
		</div>
		
		<div style="width:700px;height:680px;margin-left:10px;">
		
		<?php
			
			if(isset($_GET['pro_id'])){
				
				$product_id = $_GET['pro_id'];
				$get_products = "select * from products where product_id='$product_id'";
				
				$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$pro_image1 = $row_products['product_img1'];
							$pro_image2 = $row_products['product_img2'];
							$pro_image3 = $row_products['product_img3'];
							
							echo "	
								<div>
									<img class='slide' src='admin_area/product_images/$pro_image1'/>
									<img class='slide' src='admin_area/product_images/$pro_image2'/>
									<img class='slide' src='admin_area/product_images/$pro_image3'/>
								</div>
								
							";
						
						}
			}
		?>
		</div>
			
		<div style="width:470px;height:auto;margin-left:50px;">
		
		<?php
			
			if(isset($_GET['pro_id'])){
				
				$product_id = $_GET['pro_id'];
				$get_products = "select * from products where product_id='$product_id'";
				
				$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_status = $row_products['status'];
							
							echo "	
								<br>
								<br>
								<b> $pro_title </b><br>
								<b> Price: </b><br>
								<b style='color:#b30000;'> $pro_price </b><br>
								<b> Delivery In 6-7 Days </b><br>
								<b style='color:green;'> $pro_status </b><br><br><br>
								<b> About Product: </b><br>
								<b style='margin-left:10px;'> $pro_desc </b><br>
							";
						
						}
			}
		?>
		</div>
		
		<div style="width:175px;height:300px;margin-left:40px;margin-top:20px;background:#FAFAFA;">
		<form method="POST" action="cart.php">
			<?php
			$i =0;
			if(isset($_GET['pro_id'])){
				
				$product_id = $_GET['pro_id'];
				$get_products = "select * from products where product_id='$product_id'";
				
				$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_status = $row_products['status'];
							$i ++;
							
							echo "	
								<form action='' method='post'>
								<input type='hidden' name='qty' value='1'>
								<a href='cart.php?pro_id=$pro_id'><button name='cart' style='width:175px;height:30px;margin-top:100px;background:#FCAE1E;cursor:pointer;'> Add to Cart </button></a>
								<a href='cart.php?pro_id=$pro_id'><button style='width:175px;height:30px;;margin-top:10px;background:#FCAE1E;cursor:pointer;'> Buy Now </button></a>
								</form>
							";
		
						}
			}
			cart();
		?>
		</form>
		
		</div>	
	</div>
	
	<div style="width:1519px;height:auto;margin-left:auto;margin-right:auto;margin-top:20px;margin-bottom:30px;text-align:center;">
		<h2 style="color:#b30000;float:left;margin-left:20px;"> Similar Products By Brands: </h2><br><br>
		<div style="width:1480px;height:auto;margin-left:20px;display:flex;background:#FAFAFA;"> 
			<?php
			if(isset($_GET['brand_id'])){
				
			$brand_id = $_GET['brand_id'];
			$get_products = "select * from products where brand_id='$brand_id' order by rand() LIMIT 0,6";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:10px;margin-right:20px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='186' height='220'/></a><br>
									<h1> $pro_title </h1>
									<b style='color:#b30000;'> $pro_price </b><br>
								</div>
							";
						
						}
			}
			?>
		</div>
	</div>
	
	<div style="width:1519px;height:auto;margin-left:auto;margin-right:auto;margin-top:40px;margin-bottom:30px;text-align:center;">
		<h2 style="color:#b30000;float:left;margin-left:20px;"> Similar Products By Categories: </h2><br><br>
		<div style="width:1480px;height:auto;margin-left:20px;display:flex;background:#FAFAFA;"> 
			<?php
			if(isset($_GET['cat_id'])){
				
			$cat_id = $_GET['cat_id'];
			$get_products = "select * from products where cat_id='$cat_id' order by rand() LIMIT 0,6";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:10px;margin-right:20px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='186' height='220'/></a><br>
									<h1> $pro_title </h1>
									<b style='color:#b30000;'> $pro_price </b><br>
								</div>
							";
						
						}
			}
			?>
		</div>
	</div>
	
	<div style="width:1519px;height:auto;margin-left:auto;margin-right:auto;margin-top:50px;margin-bottom:30px;text-align:center;">
	<?php
			
			if(isset($_GET['pro_id'])){
				
				$product_id = $_GET['pro_id'];
				$get_products = "select * from products where product_id='$product_id'";
				
				$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$pro_title = $row_products['product_title'];
							$pro_image1 = $row_products['product_img1'];
							$pro_image2 = $row_products['product_img2'];
							$pro_image3 = $row_products['product_img3'];
							
							echo "	
									<b> $pro_title </b><br>
									<img src='admin_area/product_images/$pro_image1' width='600' height='600'/>
									<img src='admin_area/product_images/$pro_image2' width='600' height='600'/>
									<img style='margin-top:20px;' src='admin_area/product_images/$pro_image3' width='600' height='600'/>
							";
						
						}
			}
		?>
	</div>
	
	<div style="width:1519px;height:auto;margin-left:auto;margin-right:auto;margin-top:20px;margin-bottom:30px;text-align:center;">
		<h2 style="color:#b30000;float:left;margin-left:20px;"> Other Products: </h2><br><br>
		<div style="width:1480px;height:auto;margin-left:20px;display:flex;background:#FAFAFA;"> 
			<?php
			if(isset($_GET['cat_id'])){
				
			$cat_id = $_GET['cat_id'];
			$get_products = "select * from products where cat_id!='$cat_id' order by rand() LIMIT 0,6";
			$run_products = mysqli_query($db, $get_products);
						
				while($row_products=mysqli_fetch_array($run_products)){
							$pro_id = $row_products['product_id'];
							$cat_id = $row_products['cat_id'];
							$brand_id = $row_products['brand_id'];
							$pro_title = $row_products['product_title'];
							$pro_desc = $row_products['product_desc'];
							$pro_price = $row_products['product_price'];
							$pro_image = $row_products['product_img1'];
							
							echo "	
								<div style ='margin-top:10px;margin-left:10px;margin-right:20px;'>
									<a href='details.php?pro_id=$pro_id&cat_id=$cat_id&brand_id=$brand_id'><img src='admin_area/product_images/$pro_image' width='186' height='220'/></a><br>
									<p> $pro_title </p>
									<b style='color:#b30000;'> $pro_price </b><br>
								</div>
							";
						
						}
			}
			?>
		</div>
	</div>
	
	<div style="width:1519px;height:300px;margin-left:auto;margin-right:auto;margin-top:10px;">
		<div style="width:1000px;height:300px;margin-left:auto;margin-right:auto;;background:#FAFAFA;"> 
		<img src="images/dg0.jpg" width="1000" height="300"/>
		</div>
	</div>
	
	<div style="width:1519px;height:auto;margin-left:auto;margin-right:auto;margin-top:40px;margin-bottom:20px;display:flex;">
		<div style="width:350px;height:400px;margin-left:24px;background:#FAFAFA;"> 
		<h2 style="margin-left:5px;margin-top:5px;">Headphones</h2>
		<div style="display:flex;">
		<?php getPro3(); ?>
		</div>
		
		<div style="display:flex;">
		<?php getPro4(); ?>
		</div>
		</div>
		
		<div style="width:350px;height:400px;margin-left:24px;background:#FAFAFA;"> 
		<h2 style="margin-left:5px;margin-top:5px;">Mobiles</h2>
		<div style="display:flex;">
		<?php getPro5(); ?>
		</div>
		
		<div style="display:flex;">
		<?php getPro6(); ?>
		</div>
		</div>
		
		<div style="width:350px;height:400px;margin-left:24px;background:#FAFAFA;"> 
		<h2 style="margin-left:5px;margin-top:5px;">Televison</h2>
		<div style="display:flex;">
		<?php getPro1(); ?>
		</div>
		
		<div style="display:flex;">
		<?php getPro2(); ?>
		</div>
		</div>
		
		<div style="width:350px;height:400px;margin-left:24px;background:#FAFAFA;"> 
		<h2 style="margin-left:5px;margin-top:5px;">Cameras & Speakers</h2>
		<div style="display:flex;">
		<?php getPro7(); ?>
		</div>
		
		<div style="display:flex;">
		<?php getPro8(); ?>
		</div>
		</div>
	</div>
	
	<div style="width:1519px;height:300px;margin-left:auto;margin-right:auto;margin-top:40px;">
		<div style="width:1000px;height:300px;margin-left:auto;margin-right:auto;;background:#FAFAFA;"> 
		<img src="images/dg1.jpg" width="1000" height="300"/>
		</div>
	</div>
	
	
	<div style="width:1519px;height:300px;margin-left:auto;margin-right:auto;margin-top:40px;margin-bottom:30px;">
		<div style="width:1471px;height:300px;margin-left:24px;background:#FAFAFA;"> 
		<div style="width:1471px;height:300px;margin-left:12px;display:flex;background:#FAFAFA;">
		<?php getPro9(); ?>
		</div>
		</div>
	</div>
	
	<div class="footer">
		<div class="content_left">
			<h2 class="content_heding">About us</h2>
			<div>
				<p>hytgfr vgth bcdtdgg vhyrdg vnmvhgfgd hjfhjgtuyghn vcdser cfrvd bfgtbngt vcdf ggghjn<br> nnbgf vcxsa njuk mklo nbv cvvcdd  vffvbb bvffshs bdvdferts vdfegerb sbdbvvfga cxasqwe vfgrt nmju cfgv</p>
					<div class="social">
						<a href="#"><span class="fab fa-facebook-f"></span></a>
						<a href="#"><span class="fab fa-twitter"></span></a>
						<a href="#"><span class="fab fa-instagram"></span></a>
						<a href="#"><span class="fab fa-youtube"></span></a>
					</div>
			</div>
		</div>
		
		<div class="content_center">
			<h2 class="content_heding">Address</h2>
				<div>
					<div>
						<span class="fas fa-map-market-alt"></span>
						<span class="text">Rajlot, India</span>
					</div>
					
					<div>
						<span class="fas fa-phone-alt"></span>
						<span class="text">+91-8200843427</span>
					</div>
					
					<div>
						<span class="fas fa-envelope"></span>
						<span class="text">dwarkish@gmail.com</span>
					</div>
				</div>
		</div>
		
		<div class="content_right">
				<h2 class="content_heding">Contact us</h2>
				<div>
					<ul class="footer-links">
						<li><a href="#.">Home</a></li>
						<li><a href="#.">About Us</a></li>
						<li><a href="#.">Features</a></li>
						<li><a href="#.">Categories</a></li>
						<li><a href="#.">Blog</a></li>
						<li><a href="#.">Contact Us</a></li>
					</ul>
				</div>
		</div>
		
	</div>
	
	<div class="copyright">Copyright © 2017 Classify - All Rights Reserved.</div>
</div>

<script src="myScript1.js"></script>

</body>
</html>


