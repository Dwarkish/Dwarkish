
<?php
include("includes/db.php");

?>

<html>
<head>
	<h1 style="text-align:center;margin-top:180px;">Contact us</h1>
</head>
<body>
	<link rel="stylesheet" href="form.css" >
	<div id="form-main">
  <div id="form-div">
    <form class="montform" id="reused_form"  style="text-align:center;">
      <p class="name">
      	<input name="name" type="text" class="feedback-input" required placeholder="Name" id="name" />
      </p>
      <p class="email">
        <input name="email" type="email" required  class="feedback-input" id="email" placeholder="Email" />
      </p>
      <p class="text">
        <textarea name="message" class="feedback-input" id="comment" placeholder="Message"></textarea>
      </p>
            <div class="submit">
        <button type="submit" name="fsubmit" class="button-blue">SUBMIT</button>
        <div class="ease"></div>
      </div>
    </form>
          <div id="error_message" style="width:100%; height:100%; display:none; ">
                <h4>Error</h4>
                Sorry there was an error sending your form.
          </div>
          <div id="success_message" style="width:100%; height:100%; display:none; ">
          <h2>Success! Your Message was Sent Successfully.</h2>
          </div>
    </div>
</div>
</body>
</html>



<?php
	if(isset($_POST['fsubmit'])){
		$fname = $_POST['name'];
		$femail = $_POST['email'];
		$fmessage = $_POST['message'];
		
		if($fname=='' OR $femail=='' OR $fmessage==''){
			
			echo "<script>alert('Please Fill all the fields')</script>";
			exit();	
		}
		else{
			
			$insert_c = "insert into contect_us (Name,email,Message) values ('$fname','$femail','$fmessage')";
			
			$run_c = mysqli_query($con,$insert_c);
			
			if($run_c){
			
			echo "<script>alert('Message Send Successfully')</script>";
			
		}
			
		}
	}
?>