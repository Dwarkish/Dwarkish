
<?php


include("includes/db.php");

?>


<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>My Shop</title>

<link rel="stylesheet" href="login.css" media="all" />

</head>

<body>
	
	<div class="login">
	<h1>Register</h1>
    <form method="post" >
		<input  type="text" name="customer_name" placeholder="Name" required="required" /><br>
		<input  type="text" name="customer_email" placeholder="Email" required="required" /><br>
		<input  type="password" name="customer_pass" placeholder="Password" required="required" /><br>
		<input  type="text" name="customer_country" placeholder="Country" required="required" /><br>
		<input  type="text" name="customer_city" placeholder="City" required="required" /><br>
		<input  type="text" name="customer_contact" placeholder="Contact" required="required" /><br>
		<input  type="text" name="customer_add" placeholder="Address" required="required" /><br>
        <button style="margin-bottom:20px;" type="submit" class="btn btn-primary btn-block btn-large" name="register">Register</button>
		<a href="login.php"><h4 style="float:right;color:white;">Already Register?</h4></a>
    </form>
</div>

</body>

</html>


<?php

	if(isset($_POST['register'])){
		
		$user_name = $_POST['customer_name'];
		$user_email = $_POST['customer_email'];
		$user_pass = $_POST['customer_pass'];
		$user_country = $_POST['customer_country'];
		$user_city = $_POST['customer_city'];
		$user_contact = $_POST['customer_contact'];
		$user_add = $_POST['customer_add'];
		
		$insert_customer = "insert into customers (customer_name,customer_email,customer_pass,customer_country,customer_city,customer_contact,customer_add) values ('$user_name','$user_email','$user_pass','$user_country','$user_city','$user_contact','$user_add')";
		
		$run_customer = mysqli_query($con,$insert_customer);
		
		if($run_customer){
			
			echo "<script>alert('Successfully Registed')</script>";
			
			echo "<script>window.open('index.php','_self')</script>";
		}
	}

?>





















