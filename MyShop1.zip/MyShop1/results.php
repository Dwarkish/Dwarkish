
<?php 
	include("includes/db.php");
	include("functions/functions.php");
?>

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>My Shop</title>

<link rel="stylesheet" href="styles/brandstyle11.css" media="all" />
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
	

	
	
	<div class="header_wrapper">
		<a href="index.php"><img src="images/logo.png"></a>
	    
		<ul class="menu">
			<li><a href="index.php">HOME</a></li>
			<li>|</li>
			<li><a href="about_us.php">ABOUT US</a></li>
			<li>|</li>
			<li><a href="categories.php">CATEGORIES</a></li>
			<li>|</li>
			<li><a href="brands.php">BRANDS</a></li>
			<li>|</li>
			<li><a href="our_services.php">OUR SERVICES</a></li>
			<li>|</li>
			<li><a href="contact_us.php">CONTACT US</a></li>
		</ul>
		
		<form method="get" action="results.php" enctype="multipart/form-data" style="margin-top:5px;margin-left:20px;">
			<input type="text" name="user_query" placeholder="Search" style="padding:10px"/>
			<input type="submit" name="search" value="Search" style="padding:10px;float:right;"/>
		</form>
		
		<ul class="menu">
			<li><a href="cart.php">CART</a></li>
			<li>
			<?php
						
						if(!isset($_SESSION['customer_email'])){
					
						echo "&nbsp;<a href='login.php'>LOGIN</a>";
						}
						else{
							
							echo "<a href='logout.php'>LOGOUT</a>";
						}
						
			?>
			</li>
		</ul>
	</div>
	
	<div class="middle_table">
		<div class="middle_table_left" style="background:white;">
			<h2 style="margin-left:15px;margin-top:6px;margin-bottom:10px;border-bottom:1px solid black;">Categories</h2>
			
			<ul id="cats" style="border-bottom:1px solid black;">
			
				<?php getCats(); ?>
			</ul>
			
		</div>
		
		<div class="middle_table_right" style="background:white;">
			<?php 
				
				if(isset($_GET['search'])){
					
					$user_keyword = $_GET['user_query'];
					$get_products = "select * from products where product_keywords like '%$user_keyword%'";
					$run_products = mysqli_query($con, $get_products);
					
					$count = mysqli_num_rows($run_products);
					
					if($count==0){
						echo "
						<h1 style='margin-left:540px;margin-top:200px;'>Ooops...</h1>
						<h1 style='margin-left:410px;'>Sorry, Product not Found!!</h1>
						";
					}
					
					while($row_products=mysqli_fetch_array($run_products)){
						$pro_id = $row_products['product_id'];
						$pro_title = $row_products['product_title'];
						$pro_desc = $row_products['product_desc'];
						$pro_price = $row_products['product_price'];
						$pro_image = $row_products['product_img1'];	
				
				echo "	
					<div style ='margin-top:20px;margin-left:15px;margin-bottom:10px;border-bottom:2px solid #EBECF0;display:flex;'>
					<a href='details.php?pro_id=$pro_id'><img src='admin_area/product_images/$pro_image' width='250' height='200'/></a><br>
					<div style='margin-top:50px;margin-left:25px;'>
					<a style='text-decoration:none;color:black;' href='details.php?pro_id=$pro_id'><b> $pro_title </b><br></a>
					<b style='color:#b30000;'> $pro_price </b>
					</div>
					</div>
					";
			}
				}
				
			?>
		</div>
	</div>
	
	
	<div class="footer">
		<div class="content_left">
			<h2 class="content_heding">About us</h2>
			<div>
				<p>hytgfr vgth bcdtdgg vhyrdg vnmvhgfgd hjfhjgtuyghn vcdser cfrvd bfgtbngt vcdf ggghjn<br> nnbgf vcxsa njuk mklo nbv cvvcdd  vffvbb bvffshs bdvdferts vdfegerb sbdbvvfga cxasqwe vfgrt nmju cfgv</p>
					<div class="social">
						<a href="#"><span class="fab fa-facebook-f"></span></a>
						<a href="#"><span class="fab fa-twitter"></span></a>
						<a href="#"><span class="fab fa-instagram"></span></a>
						<a href="#"><span class="fab fa-youtube"></span></a>
					</div>
			</div>
		</div>
		
		<div class="content_center">
			<h2 class="content_heding">Address</h2>
				<div>
					<div>
						<span class="fas fa-map-market-alt"></span>
						<span class="text">Rajlot, India</span>
					</div>
					
					<div>
						<span class="fas fa-phone-alt"></span>
						<span class="text">+91-8200843427</span>
					</div>
					
					<div>
						<span class="fas fa-envelope"></span>
						<span class="text">dwarkish@gmail.com</span>
					</div>
				</div>
		</div>
		
		<div class="content_right">
				<h2 class="content_heding">Contact us</h2>
				<div>
					<ul class="footer-links">
						<li><a href="#.">Home</a></li>
						<li><a href="#.">About Us</a></li>
						<li><a href="#.">Features</a></li>
						<li><a href="#.">Categories</a></li>
						<li><a href="#.">Blog</a></li>
						<li><a href="#.">Contact Us</a></li>
					</ul>
				</div>
		</div>
		
	</div>
	
	<div class="copyright">Copyright © 2017 Classify - All Rights Reserved.</div>

</body>
</html>


