
<?php


include("includes/db.php");

?>


<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>My Shop</title>

<link rel="stylesheet" href="login.css" media="all" />

</head>

<body>
	
	<div class="login">
	<h1>Enter Your Email</h1>
    <form method="post" >
		<input  type="text" name="email" placeholder="Email" required="required" /><br>
        <button style="margin-bottom:20px;" type="submit" class="btn btn-primary btn-block btn-large" name="submit">Submit</button>
		
    </form>
</div>

</body>

</html>

<?php

	if(isset($_POST['submit'])){
		
			$c_email = $_POST['email'];
			$sel_c = "select * form customers where customer_email='$c_email'";
			
			$run_c = mysqli_query($con, $sel_c);
			
			$check_c = mysqli_num_rows($run_c);
			
			$row_c = mysqli_fetch_array($run_c);
			
			$c_name = $row_c['customer_name'];
			$c_pass = $row_c['customer_pass'];
			
			if($check_c==0){
				
				echo "<script>alert('This Email not Valid!')</script>";
				exit();
			}
			else{
				
				$from = 'admin@mysite.com';
				$subject = 'Your Password';
				$message = "
				
				<html>
					<h3>$c_name</h3>
					<p>You requested for your password at www.mysite.com</p>
					<h4>Your Password is </b><span style='color:red;'>$c_pass</span>
					
					<h3>Thank You</h3>
				</html>
				";
				
				mail($c_email,$subject,$message,$from);
				
				echo "<script>alert('Password was sent your Email!')</script>";
				echo "<script>window.open('checkout.php','_self')</script>";
			}
		}

?>